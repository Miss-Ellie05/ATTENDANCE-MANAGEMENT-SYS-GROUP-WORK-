package com.attendify.model;

import javax.persistence.*;
import java.util.Date;

@Entity
public class CheckIn {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    private String classCode;
    private Date checkInTime;
    private String location;

    // Getters and Setters
}