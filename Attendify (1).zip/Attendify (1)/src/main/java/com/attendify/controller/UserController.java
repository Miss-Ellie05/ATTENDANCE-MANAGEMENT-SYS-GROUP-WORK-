package com.attendify.controller;

import com.attendify.model.User;
import com.attendify.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;


@RestController
@RequestMapping("/api/users")
public class UserController {
    @Autowired
    private UserService userService;
    private BCryptPasswordEncoder passwordEncoder;

    @PostMapping("/register")
public User register(@RequestBody User user) {
    user.setPasswordHash(passwordEncoder.encode(user.getPasswordHash())); // Hash the password
    return userService.registerUser(user);
    }

    @PutMapping("/profile")
public User updateProfile(@RequestBody User user) {
    return userService.updateUser(user); // Implement this method in UserService
}
@GetMapping("/search")
public List<User> searchUsers(@RequestParam String query) {
    return userService.searchUsers(query); // Implement this method in UserService
}
}



