@RestController
@RequestMapping("/api/assignments")
public class AssignmentController {
    @Autowired
    private AssignmentService assignmentService;

    @PostMapping("/submit")
    public Assignment submitAssignment(@RequestBody Assignment assignment) {
        return assignmentService.submitAssignment(assignment);
    }
}