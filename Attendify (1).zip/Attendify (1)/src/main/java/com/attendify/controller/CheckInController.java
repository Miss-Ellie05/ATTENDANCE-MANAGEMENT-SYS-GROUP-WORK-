package com.attendify.controller;

import com.attendify.model.CheckIn;
import com.attendify.service.CheckInService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/checkins")
public class CheckInController {
    @Autowired
    private CheckInService checkInService;

    @PostMapping
    public CheckIn recordCheckIn(@RequestBody CheckIn checkIn) {
        return checkInService.recordCheckIn(checkIn);
    }
}