@RestController
@RequestMapping("/api/attendance")
public class AttendanceController {
    @Autowired
    private AttendanceService attendanceService;

    @GetMapping("/reports")
    public List<Attendance> getAttendanceReports(@RequestParam Long userId) {
        return attendanceService.getAttendanceReports(userId);
    }
}