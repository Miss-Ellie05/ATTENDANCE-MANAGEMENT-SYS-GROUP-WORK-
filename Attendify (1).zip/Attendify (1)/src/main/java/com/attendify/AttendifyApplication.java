package com.example.Attendify;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AttendifyApplication {

	public static void main(String[] args) {
		SpringApplication.run(AttendifyApplication.class, args);
	}

}
