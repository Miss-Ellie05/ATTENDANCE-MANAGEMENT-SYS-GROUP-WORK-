import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.GetMapping;

@TestController
@RequestMapping("/api")
public class TestController {
    @GetMapping("/hello")
    public String sayHello() {
        return "Hello, Spring Boot!";
    }

}