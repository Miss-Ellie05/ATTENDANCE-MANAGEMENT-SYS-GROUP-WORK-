package com.attendify.service;

import com.attendify.model.User;
import com.attendify.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    public User registerUser(User user) {
        // Hash the password and save the user
        return userRepository.save(user);
    }
}