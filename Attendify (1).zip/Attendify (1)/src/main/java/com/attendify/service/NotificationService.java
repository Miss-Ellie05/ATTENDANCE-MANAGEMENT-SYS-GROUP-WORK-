@Service
public class NotificationService {
    public void sendNotification(String message, User user) {
        // Logic to send notifications
    }
}