package com.attendify.service;

import com.attendify.model.CheckIn;
import com.attendify.repository.CheckInRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CheckInService {
    @Autowired
    private CheckInRepository checkInRepository;

    public CheckIn recordCheckIn(CheckIn checkIn) {
        return checkInRepository.save(checkIn);
    }
}