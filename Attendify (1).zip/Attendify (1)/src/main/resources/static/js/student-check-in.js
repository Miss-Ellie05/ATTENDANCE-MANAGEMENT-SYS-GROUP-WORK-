// Function to handle manual check-in
function handleManualCheckIn(event) {
    event.preventDefault(); // Prevent the default form submission

    const classCode = document.getElementById('classCode').value;

    const checkInData = {
        classCode: classCode,
        // You can add more data here if needed (e.g., user ID, timestamp)
    };

    fetch('/api/checkins', { // Update this URL to match your backend endpoint
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(checkInData),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        alert('Check-in successful!');
        // Optionally, you can update the UI with the new data or reset the form
        document.getElementById('manualCheckInForm').reset();
    })
    .catch(error => {
        console.error('Error during check-in:', error);
        alert('Check-in failed. Please try again.');
    });
}

// Function to handle feedback submission
function submitFeedback() {
    const feedbackMessage = document.getElementById('feedbackMessage').value;

    const feedbackData = {
        message: feedbackMessage,
    };

    fetch('/api/feedback', { // Update this URL to match your backend endpoint
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(feedbackData),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        alert('Feedback submitted successfully!');
        document.getElementById('feedbackMessage').value = ''; // Clear the textarea
    })
    .catch(error => {
        console.error('Error submitting feedback:', error);
        alert('Failed to submit feedback. Please try again.');
    });
}

// QR Code Scanner Initialization
const html5QrCode = new Html5Qrcode("reader");

function startScanner() {
    const config = { fps: 10, qrbox: 250 };
    html5QrCode.start(
        { facingMode: "environment" }, // Use the environment camera
        config,
        qrCodeMessage => {
            // Handle the QR code message
            document.getElementById('result-text').innerText = qrCodeMessage;
            document.getElementById('result').classList.remove('d-none');
            // Optionally, you can call the check-in function here
            handleManualCheckIn({ preventDefault: () => {} }); // Simulate form submission
        },
        errorMessage => {
            // Handle scanning errors
            console.warn(`QR Code scan error: ${errorMessage}`);
        }
    ).catch(err => {
        console.error(`Failed to start scanning: ${err}`);
    });
}

// Attach event listeners
document.getElementById('manualCheckInForm').addEventListener('submit', handleManualCheckIn);
document.getElementById('feedbackForm').addEventListener('submit', submitFeedback);
document.getElementById('startButton').addEventListener('click', startScanner);