let html5QrcodeScanner = null;
let locationPermissionGranted = false;

// Initialize the QR scanner
function initializeScanner() {
    const config = {
        fps: 10,
        qrbox: { width: 250, height: 250 },
        aspectRatio: 1.0
    };
    
    html5QrcodeScanner = new Html5Qrcode("reader");
    
    document.getElementById('startButton').addEventListener('click', () => {
        startScanner();
    });
    
    document.getElementById('stopButton').addEventListener('click', () => {
        stopScanner();
    });

    // Check for geolocation permission
    checkLocationPermission();
}

// Start the QR scanner
async function startScanner() {
    try {
        await html5QrcodeScanner.start(
            { facingMode: "environment" },
            {
                fps: 10,
                qrbox: { width: 250, height: 250 }
            },
            onScanSuccess,
            onScanFailure
        );
        
        document.getElementById('startButton').classList.add('d-none');
        document.getElementById('stopButton').classList.remove('d-none');
    } catch (err) {
        showError('Camera access denied. Please enable camera access to scan QR codes.');
    }
}

// Stop the QR scanner
async function stopScanner() {
    try {
        await html5QrcodeScanner.stop();
        document.getElementById('startButton').classList.remove('d-none');
        document.getElementById('stopButton').classList.add('d-none');
    } catch (err) {
        console.error('Error stopping scanner:', err);
    }
}

// Handle successful QR scan
async function onScanSuccess(decodedText, decodedResult) {
    try {
        // Stop the scanner after successful scan
        await stopScanner();
        
        // Verify location before processing the QR code
        if (!locationPermissionGranted) {
            showError('Location access is required for attendance verification.');
            return;
        }

        // Process the QR code data
        const qrData = JSON.parse(decodedText);
        await processAttendance(qrData);
        
    } catch (err) {
        showError('Invalid QR code format.');
    }
}

// Handle QR scan failure
function onScanFailure(error) {
    // Handle scan failure silently as it happens frequently
    console.debug(`QR scan error: ${error}`);
}

// Process attendance with location verification
async function processAttendance(qrData) {
    try {
        const position = await getCurrentPosition();
        
        // In a real application, you would send this data to your backend
        const attendanceData = {
            classCode: qrData.classCode,
            timestamp: new Date().toISOString(),
            location: {
                latitude: position.coords.latitude,
                longitude: position.coords.longitude
            }
        };

        // Simulate API call
        setTimeout(() => {
            showSuccess('Attendance recorded successfully!');
        }, 1000);
        
    } catch (err) {
        showError('Failed to verify location. Please ensure location services are enabled.');
    }
}

// Get current position
function getCurrentPosition() {
    return new Promise((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
            enableHighAccuracy: true,
            timeout: 5000,
            maximumAge: 0
        });
    });
}

// Check location permission
function checkLocationPermission() {
    if ('geolocation' in navigator) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                locationPermissionGranted = true;
                document.getElementById('location-status').innerHTML = 
                    '<i class="fas fa-check-circle text-success me-2"></i>Location verified';
            },
            (error) => {
                locationPermissionGranted = false;
                document.getElementById('location-status').innerHTML = 
                    '<i class="fas fa-exclamation-circle text-danger me-2"></i>Location access required';
            }
        );
    } else {
        locationPermissionGranted = false;
        document.getElementById('location-status').innerHTML = 
            '<i class="fas fa-times-circle text-danger me-2"></i>Location not supported';
    }
}

// Handle manual check-in
async function handleManualCheckIn(event) {
    event.preventDefault();
    
    if (!locationPermissionGranted) {
        showError('Location access is required for attendance verification.');
        return false;
    }

    const classCode = document.getElementById('classCode').value;
    
    try {
        await processAttendance({ classCode });
    } catch (err) {
        showError('Failed to record attendance. Please try again.');
    }

    return false;
}

// Show success message
function showSuccess(message) {
    const resultDiv = document.getElementById('result');
    const resultText = document.getElementById('result-text');
    const errorDiv = document.getElementById('error');
    
    resultText.textContent = message;
    resultDiv.classList.remove('d-none');
    errorDiv.classList.add('d-none');
}

// Show error message
function showError(message) {
    const errorDiv = document.getElementById('error');
    const errorText = document.getElementById('error-text');
    const resultDiv = document.getElementById('result');
    
    errorText.textContent = message;
    errorDiv.classList.remove('d-none');
    resultDiv.classList.add('d-none');
}

// Initialize when the page loads
window.addEventListener('load', initializeScanner);

// Function to handle manual check-in
function handleManualCheckIn(event) {
    event.preventDefault(); // Prevent the default form submission

    const classCode = document.getElementById('classCode').value;

    const checkInData = {
        classCode: classCode,
        // You can add more data here if needed (e.g., user ID, timestamp)
    };

    fetch('/api/checkins', { // Update this URL to match your backend endpoint
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(checkInData),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        alert('Check-in successful!');
        // Optionally, you can update the UI with the new data or reset the form
        document.getElementById('manualCheckInForm').reset();
    })
    .catch(error => {
        console.error('Error during check-in:', error);
        alert('Check-in failed. Please try again.');
    });
}

// Function to handle feedback submission
function submitFeedback() {
    const feedbackMessage = document.getElementById('feedbackMessage').value;

    const feedbackData = {
        message: feedbackMessage,
    };

    fetch('/api/feedback', { // Update this URL to match your backend endpoint
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(feedbackData),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        alert('Feedback submitted successfully!');
        document.getElementById('feedbackMessage').value = ''; // Clear the textarea
    })
    .catch(error => {
        console.error('Error submitting feedback:', error);
        alert('Failed to submit feedback. Please try again.');
    });
}

// QR Code Scanner Initialization
const html5QrCode = new Html5Qrcode("reader");

function startScanner() {
    const config = { fps: 10, qrbox: 250 };
    html5QrCode.start(
        { facingMode: "environment" }, // Use the environment camera
        config,
        qrCodeMessage => {
            // Handle the QR code message
            document.getElementById('result-text').innerText = qrCodeMessage;
            document.getElementById('result').classList.remove('d-none');
            // Optionally, you can call the check-in function here
            handleManualCheckIn({ preventDefault: () => {} }); // Simulate form submission
        },
        errorMessage => {
            // Handle scanning errors
            console.warn(`QR Code scan error: ${errorMessage}`);
        }
    ).catch(err => {
        console.error(`Failed to start scanning: ${err}`);
    });
}

// Attach event listeners
document.getElementById('manualCheckInForm').addEventListener('submit', handleManualCheckIn);
document.getElementById('feedbackForm').addEventListener('submit', submitFeedback);
document.getElementById('startButton').addEventListener('click', startScanner);