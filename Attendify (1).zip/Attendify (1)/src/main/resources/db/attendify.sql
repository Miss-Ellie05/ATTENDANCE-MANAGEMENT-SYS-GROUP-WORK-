CREATE DATABASE Attendify;

USE Attendify;

-- Table for user roles
CREATE TABLE UserRoles (
    RoleID INT AUTO_INCREMENT PRIMARY KEY,
    RoleName VARCHAR(50) NOT NULL
);

-- Table for users
CREATE TABLE Users (
    UserID INT AUTO_INCREMENT PRIMARY KEY,
    FullName VARCHAR(100) NOT NULL,
    Email VARCHAR(100) UNIQUE NOT NULL,
    PasswordHash VARCHAR(255) NOT NULL,
    RoleID INT NOT NULL,
    IDNumber VARCHAR(50) NOT NULL,
    FOREIGN KEY (RoleID) REFERENCES UserRoles(RoleID)
);

-- Prepopulate roles
INSERT INTO UserRoles (RoleName) VALUES ('Student'), ('Lecturer');



CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone_number VARCHAR(15),
    program VARCHAR(100)
);

CREATE TABLE lecturers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone_number VARCHAR(15),
    department VARCHAR(100)
);

CREATE TABLE courses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_name VARCHAR(100) NOT NULL,
    lecturer_id INT,
    FOREIGN KEY (lecturer_id) REFERENCES lecturers(id)
);

CREATE TABLE assignments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT,
    title VARCHAR(100) NOT NULL,
    description TEXT,
    due_date DATETIME,
    FOREIGN KEY (course_id) REFERENCES courses(id)
);

CREATE TABLE attendance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    course_id INT,
    date DATE NOT NULL,
    status ENUM('Present', 'Absent'),
    FOREIGN KEY (student_id) REFERENCES students(id),
    FOREIGN KEY (course_id) REFERENCES courses(id)
);

CREATE TABLE lecturer_check_ins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    lecturer_id INT,
    class_code VARCHAR(100) NOT NULL,
    check_in_time DATETIME NOT NULL,
    location VARCHAR(255),
    FOREIGN KEY (lecturer_id) REFERENCES lecturers(id)
);

CREATE TABLE student_check_ins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    class_code VARCHAR(100) NOT NULL,
    check_in_time DATETIME NOT NULL,
    location VARCHAR(255),
    FOREIGN KEY (student_id) REFERENCES students(id)
);