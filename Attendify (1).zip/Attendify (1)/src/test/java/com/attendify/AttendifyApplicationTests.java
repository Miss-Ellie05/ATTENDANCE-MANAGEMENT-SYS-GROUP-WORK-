package com.example.Attendify;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AttendifyApplicationTests {

	@Test
	void contextLoads() {
	}

}
