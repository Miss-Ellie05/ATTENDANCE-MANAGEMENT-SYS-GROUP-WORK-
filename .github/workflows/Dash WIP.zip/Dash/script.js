// Get references to elements
const toggleBtn = document.getElementById("toggle-btn");
const sidebar = document.getElementById("sidebar");
const mainContent = document.querySelector(".main-content");
const contentSection = document.getElementById("content");

// Toggle sidebar visibility
toggleBtn.addEventListener("click", () => {
  sidebar.classList.toggle("active");
  mainContent.classList.toggle("active");
});

// Load Dashboard Overview
document.getElementById("dashboard-link").addEventListener("click", () => {
  contentSection.innerHTML = `
    <div class="dashboard-section">
      <h2>Dashboard Overview</h2>
      <div class="card">
        <div class="card-header">Summary</div>
        <div class="card-body">
          <ul>
            <li>Total Users: 150</li>
            <li>Active Users: 120</li>
            <li>Pending Approvals: 5</li>
          </ul>
        </div>
      </div>
    </div>
  `;
});

// Load User Management
document.getElementById("users-link").addEventListener("click", () => {
  contentSection.innerHTML = `
    <div class="dashboard-section">
      <h2>User Management</h2>
      <div class="card">
        <div class="card-header">Manage Users</div>
        <div class="card-body">
          <ul>
            <li>User1 - Active</li>
            <li>User2 - Active</li>
            <li>User3 - Inactive</li>
          </ul>
        </div>
      </div>
    </div>
  `;
});

// Load Reports and Analytics
document.getElementById("reports-link").addEventListener("click", () => {
  contentSection.innerHTML = `
    <div class="dashboard-section">
      <h2>Reports & Analytics</h2>
      <div class="card">
        <div class="card-header">Attendance Report</div>
        <div class="card-body">
          <p>Report data will be shown here...</p>
        </div>
      </div>
    </div>
  `;
});

// Load Settings
document.getElementById("settings-link").addEventListener("click", () => {
  contentSection.innerHTML = `
    <div class="dashboard-section">
      <h2>Settings</h2>
      <div class="card">
        <div class="card-header">Configure System</div>
        <div class="card-body">
          <p>System settings and configurations will appear here.</p>
        </div>
      </div>
    </div>
  `;
});

// Load Notifications
document.getElementById("notifications-link").addEventListener("click", () => {
  contentSection.innerHTML = `
    <div class="dashboard-section">
      <h2>Notifications</h2>
      <div class="card">
        <div class="card-header">Recent Alerts</div>
        <div class="card-body">
          <ul>
            <li>Alert 1: System maintenance scheduled.</li>
            <li>Alert 2: New user registered.</li>
            <li>Alert 3: Monthly report generated.</li>
          </ul>
        </div>
      </div>
    </div>
  `;
});
